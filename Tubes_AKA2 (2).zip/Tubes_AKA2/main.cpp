#include <iostream>
#include "rekursif.h"
using namespace std;

int main() {
    LibraryRecursive library;
    library.bookCount = 0; // Inisialisasi jumlah buku

    int jumlahBuku; // Variabel untuk jumlah buku yang ingin ditambahkan
    cout << "== SISTEM MANAJEMEN BUKU (Rekursif) ==" << endl;
    cout << "Masukkan jumlah buku yang ingin ditambahkan: ";
    cin >> jumlahBuku;

    // Tambahkan buku secara otomatis
    addBooksRecursive(&library, jumlahBuku);

    // Tampilkan daftar buku
    displayBooksRecursive(&library);

    return 0;
}
