#ifndef REKURSIF_H_INCLUDED
#define REKURSIF_H_INCLUDED

#include <iostream>
using namespace std;

#define MAX_BOOKS 1000 // Kapasitas maksimum perpustakaan

typedef struct {
    string books[MAX_BOOKS];
    int bookCount;
} LibraryRecursive;

void addBooksRecursive(LibraryRecursive* library, int totalBooks);
void displayBooksRecursive(const LibraryRecursive* library);

#endif // REKURSIF_H_INCLUDED
