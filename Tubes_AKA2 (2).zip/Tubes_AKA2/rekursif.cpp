#include <iostream>
#include "rekursif.h"
using namespace std;

// Fungsi rekursif untuk menambahkan banyak buku
void addBooksRecursiveHelper(LibraryRecursive* library, int current, int total) {
    if (current == total) return; // Basis rekursi: selesai menambahkan semua buku

    // Judul buku otomatis
    string bookTitle = "Buku" + to_string(library->bookCount + 1);

    // Tambahkan buku ke perpustakaan
    if (library->bookCount < MAX_BOOKS) {
        library->books[library->bookCount++] = bookTitle;
    } else {
        cout << "Perpustakaan penuh, tidak bisa menambahkan buku lagi." << endl;
        return;
    }

    // Panggilan rekursif untuk buku berikutnya
    addBooksRecursiveHelper(library, current + 1, total);
}

void addBooksRecursive(LibraryRecursive* library, int totalBooks) {
    addBooksRecursiveHelper(library, 0, totalBooks); // Mulai dari buku pertama
}

void displayBooksRecursiveHelper(const LibraryRecursive* library, int index) {
    if (index == library->bookCount) {
        return;
    }
    cout << index + 1 << ". " << library->books[index] << endl;
    displayBooksRecursiveHelper(library, index + 1);
}

void displayBooksRecursive(const LibraryRecursive* library) {
    cout << "\nDaftar Buku (Rekursif):" << endl;
    displayBooksRecursiveHelper(library, 0);
}
