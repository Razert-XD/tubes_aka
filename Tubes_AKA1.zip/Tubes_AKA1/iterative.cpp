#include <iostream>
#include "iterative.h"
using namespace std;

void addBookIterative(LibraryIterative* library, const string& bookTitle) {
    if (library->bookCount < MAX_BOOKS) {
        library->books[library->bookCount++] = bookTitle;
    } else {
        cout << "Perpustakaan penuh, tidak bisa menambahkan buku lagi." << endl;
    }
}

void displayBooksIterative(const LibraryIterative* library) {
    cout << "\nDaftar Buku (Iteratif):" << endl;
    for (int i = 0; i < library->bookCount; ++i) {
        cout << i + 1 << ". " << library->books[i] << endl;
    }
}
