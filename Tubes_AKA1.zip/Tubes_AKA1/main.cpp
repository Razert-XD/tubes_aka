#include <iostream>
#include "iterative.h"
using namespace std;

// Fungsi utama
int main() {
    LibraryIterative library;
    library.bookCount = 0; // Inisialisasi jumlah buku

    int jumlahBuku; // Variabel untuk jumlah buku yang ingin ditambahkan
    cout << "== SISTEM MANAJEMEN BUKU (Iteratif) ==" << endl;
    cout << "Masukkan jumlah buku yang ingin ditambahkan: ";
    cin >> jumlahBuku;

    // Tambahkan buku secara otomatis
    for (int i = 0; i < jumlahBuku; i++) {
        string bookTitle = "Buku" + to_string(library.bookCount + 1); // Judul buku otomatis
        if (library.bookCount < MAX_BOOKS) {
            library.books[library.bookCount++] = bookTitle;
        } else {
            cout << "Perpustakaan penuh, tidak bisa menambahkan buku lagi." << endl;
            break;
        }
    }

    // Tampilkan daftar buku
    displayBooksIterative(&library);

    return 0;
}
