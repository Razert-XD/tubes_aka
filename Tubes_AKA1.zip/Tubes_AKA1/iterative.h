#ifndef ITERATIve_H_INCLUDED
#define ITERATIve_H_INCLUDED

#include <iostream>
using namespace std;

#define MAX_BOOKS 5000

typedef struct {
    string books[MAX_BOOKS];
    int bookCount;
} LibraryIterative;

void addBookIterative(LibraryIterative* library, const string& bookTitle);
void displayBooksIterative(const LibraryIterative* library);

#endif // ITERATIF_H_INCLUDED
